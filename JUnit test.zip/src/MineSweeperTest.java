import static org.junit.Assert.*;

import javax.swing.JButton;

import org.junit.Test;

public class MineSweeperTest {
	
	Button myarray[][];
	
	
	
	
	MineSweeper ms = new MineSweeper();

	@Test
	public void testInit() {
		fail("Not yet implemented");
	}

	@Test
	public void testSet() {
		fail("Not yet implemented");
	}

	@Test
	public void testReset() {
		fail("Not yet implemented");
	}

	@Test
	public void testCreateMenuBar() {
		fail("Not yet implemented");
	}

	@Test
	public void testPlaceMines() {
		
		
		//fail("Not yet implemented");
	}

	@Test
	public void testCountAdjacentMines() {
		fail("Not yet implemented");
	}

	@Test
	public void testRevealNeighboringMines() {
		fail("Not yet implemented");
	}

	@Test
	public void testDisableButtons() {
		fail("Not yet implemented");
	}

	@Test
	public void testRevealAllMines() {
		fail("Not yet implemented");
	}

	@Test
	public void testAdvanceState() {
		fail("Not yet implemented");
	}

	@Test
	public void testCheckWin() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetTopScores() {
		fail("Not yet implemented");
	}

	@Test
	public void testActionPerformed() {
		fail("Not yet implemented");
	}

	@Test
	public void testMouseReleased() {
		fail("Not yet implemented");
	}

	@Test
	public void testMouseExited() {
		fail("Not yet implemented");
	}

	@Test
	public void testMouseClicked() {
		fail("Not yet implemented");
	}

	@Test
	public void testMouseEntered() {
		fail("Not yet implemented");
	}

	@Test
	public void testMousePressed() {
		fail("Not yet implemented");
	}

}
