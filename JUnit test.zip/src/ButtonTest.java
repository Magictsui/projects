import static org.junit.Assert.*;
import javax.swing.*;
import java.awt.*;

import org.junit.Test;
import org.junit.Assert;
public class ButtonTest {
	
	
	boolean isMine;
	Button button = new Button();
	private JButton button1 = button.getButton();
	Character[] state = new Character[]{(char) 0, 'M', '?'};
	char num1 = (char) 0;
	int adjacentMine = 0;
	int count = 0;
	private Integer adjacentMines;
	
	//boolean isMine = true;
	
	//@Test
	/*public void testButton() {
		//fail("Not yet implemented");
	}*/

	@Test
	public void testGetStates() {
		//button.getStates();
		Assert.assertArrayEquals( state, button.getStates());
		//fail("Not yet implemented");
	}

	@Test
	public void testGetCurrentState() {
		//assertTrue(state[0].equals(button.getCurrentState()));
		Assert.assertEquals(0, button.getCurrentState());
		//fail("Not yet implemented");
	}

	@Test
	public void testSetCurrentState() {
		button.setCurrentState(num1);
		Assert.assertEquals((char) 0, button.getCurrentState());
		//fail("Not yet implemented");
	}

	@Test
	public void testReveal() {
		button.setAdjacentMines(3);
		button1.setText(button.getAdjacentMines().toString());
		assertEquals("3",button1.getText());
		
		//fail("Not yet implemented");
	}

	@Test
	public void testSetText() {
		button1.setText("test");
		Assert.assertEquals("test", button1.getText());
		//fail("Not yet implemented");
	}

	@Test
	public void testRevealed() {
		button.setCurrentState((char) 1);
		
		Assert.assertEquals(true, button.revealed());
		//fail("Not yet implemented");
	}

	@Test
	public void testGetButton() {
		//button1.getUIClassID();
		//Assert.assertEquals(button, button.getButton());
		//fail("Not yet implemented");
		Assert.assertEquals(button1.getUIClassID(), "ButtonUI");
		
	}

	@Test
	public void testIsMine() {
		button.setMine();
		Assert.assertEquals(true, button.isMine());
		//fail("Not yet implemented");
	}

	@Test
	public void testSetMine() {
		isMine = true;
		assertEquals(true,isMine);
		//Assert.assertEquals(button.setMine(), true);
		//assertEquals(true,button.setMine());
		//fail("Not yet implemented");
	}

	@Test
	public void testSetAdjacentMines() {
		
		adjacentMines = 3;
		assert(adjacentMines.equals(3));
		//button.setAdjacentMines(count);
		//assertEquals(0,adjacentMines);
		//fail("Not yet implemented");
	}

	@Test
	public void testGetAdjacentMines() {
		button.setAdjacentMines(0);
		assert(button.getAdjacentMines().equals(0));
		//fail("Not yet implemented");
	}

}
