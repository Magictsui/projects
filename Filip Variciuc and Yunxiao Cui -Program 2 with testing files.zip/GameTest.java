//
//Filip Variciuc and Yunxiao Cui
//JUnit testing on MineSweeper and Button class
//CS 342 Program 2
//

import static org.junit.Assert.*;

import javax.swing.*;

import org.junit.Test;
import org.junit.Assert;

public class GameTest
{
    MineSweeper mineSweeper = new MineSweeper();
    Button button = new Button();
    private JButton button1 = button.getButton();
    Character[] state = new Character[]{(char) 0, 'M', '?'};
    char num1 = (char) 0;
    int count = 0;


    @Test
    public void testGetStates()
    {
        button.getStates();
        Assert.assertArrayEquals(state, button.getStates());
    }


    @Test
    public void testGetCurrentState()
    {
        //when a button is first created, its state should be ""
        Assert.assertEquals(0, button.getCurrentState());
    }


    @Test
    public void TestWinningState()
    {
        mineSweeper.set();
        mineSweeper.miss = 90;
        mineSweeper.checkWin();
        for (Button[] b : mineSweeper.mineArray)
            for (Button b1 : b)
                assert (b1.getButton().isEnabled() == false);
    }


    @Test
    public void testSetCurrentState()
    {
        button.setCurrentState(num1);
        Assert.assertEquals((char) 0, button.getCurrentState());
    }


    @Test
    public void TestRevealNeighboringMines()
    {
        mineSweeper.set();
        if (!mineSweeper.mineArray[1][1].isMine())
        {
            mineSweeper.mineArray[0][0].setMine();
            mineSweeper.mineArray[0][1].setMine();
            mineSweeper.mineArray[0][2].setMine();
            mineSweeper.mineArray[1][0].setMine();
            mineSweeper.mineArray[1][2].setMine();
            mineSweeper.mineArray[2][0].setMine();
            mineSweeper.mineArray[2][1].setMine();
            mineSweeper.mineArray[2][2].setMine();

            mineSweeper.revealNeighboringMines(1, 1);
            assert (mineSweeper.mineArray[1][1].getButton().getText().equals(
                    mineSweeper.mineArray[1][1].getAdjacentMines()
                            .toString()));
        }
    }


    @Test
    public void testRevealed()
    {

        button.setCurrentState((char) 1);
        Assert.assertEquals(true, button.revealed());

    }


    @Test
    public void testTimer()
    {
        mineSweeper.set();
        mineSweeper.reset();
        assert (mineSweeper.activeTimer);
    }


    @Test
    public void testGetButton()
    {
        Assert.assertEquals(button1.getUIClassID(), "ButtonUI");
    }


    @Test
    public void testIsMine()
    {
        button.setMine();
        Assert.assertEquals(true, button.isMine());
    }


    @Test
    public void TestPlacingAndCountingMines()
    {
        int count = 0;

        mineSweeper.set();

        //clear all mines from array
        for (Button[] b : mineSweeper.mineArray)
            for (Button b1 : b)
                b1.isMine = false;

        //fill with 10 bombs
        for (int i = 0; i < 2; i++)
            for (int j = 0; j < 5; j++)
                mineSweeper.mineArray[i][j].setMine();

        for (Button[] b : mineSweeper.mineArray)
            for (Button b1 : b)
                if (b1.isMine())
                    count++;

        assertEquals("There should be 10 mines placed on the board", 10, count);
    }


    @Test
    public void testSetAdjacentMines()
    {
        mineSweeper.set();
        mineSweeper.reset();
        button.setAdjacentMines(5);
        assert (button.getAdjacentMines().equals(5));
        button.setAdjacentMines(count);
    }


    @Test
    public void testGetAdjacentMines()
    {
        mineSweeper.set();
        mineSweeper.placeMines();
        button.setAdjacentMines(0);
        assert (button.getAdjacentMines().equals(0));
    }


    @Test
    public void testAdjacentMine2()
    {
        mineSweeper.set();
        if (!mineSweeper.mineArray[1][1].isMine())
        {
            mineSweeper.mineArray[0][0].setMine();
            mineSweeper.mineArray[0][1].setMine();
            mineSweeper.mineArray[0][2].setMine();
            mineSweeper.mineArray[1][0].setMine();
            mineSweeper.mineArray[1][2].setMine();
            mineSweeper.mineArray[2][0].setMine();
            mineSweeper.mineArray[2][1].setMine();
            mineSweeper.mineArray[2][2].setMine();
            mineSweeper.countAdjacentMines();
            assert (mineSweeper.mineArray[1][1].getAdjacentMines() == 8);
        }
    }


    @Test
    public void testAdvanceState()
    {
        button.setCurrentState((char) 1);
        assert (button.getCurrentState() == 1);
    }


    @Test
    public void testDisable()
    {
        mineSweeper.set();
        mineSweeper.disableButtons();
        assert (!mineSweeper.mineArray[5][5].getButton().isEnabled());
    }


    @Test
    public void testAdjacentMine()
    {
        mineSweeper.set();
        mineSweeper.mineArray[1][1].setMine();
        mineSweeper.mineArray[0][1].setMine();
        mineSweeper.mineArray[1][0].setMine();
        mineSweeper.countAdjacentMines();
        assert (mineSweeper.mineArray[0][0].getAdjacentMines() == 3);
    }

}
